import UserRepository from './user-repository.js';

export {
    UserRepository
}